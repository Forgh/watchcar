package com.watchcar.applets;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.SwingUtilities;

import org.gstreamer.Element;
import org.gstreamer.ElementFactory;
import org.gstreamer.Gst;
import org.gstreamer.Pipeline;
import org.gstreamer.State;
import org.gstreamer.swing.VideoComponent;

@SuppressWarnings("serial")
public class TCPPipeline extends Applet {
		private static Pipeline pipe;

	    public void init()
	        {
	        // Quartz is abysmally slow at scaling video for some reason, so turn it off.
//	        System.setProperty("apple.awt.graphics.UseQuartz", "false");

	        Gst.init();
	        pipe = new Pipeline("TCPPipeline");
	        final Element videosrc = ElementFactory.make("tcpclientsrc", "source");
	        videosrc.set("host", this.getParameter("address")); //Ip du serveur
			videosrc.set("port", 5000);
	        /*final Element videofilter = ElementFactory.make("capsfilter", "flt");
	        videofilter.setCaps(Caps.fromString("video/x-raw-yuv, width=320, height=240"
	                + ", bpp=32, depth=32, framerate=25/1"));*/
	        SwingUtilities.invokeLater(new Runnable()
	            {
	            public void run()
	                {
	                // Create the video component and link it in
	                VideoComponent videoComponent = new VideoComponent();
	                videoComponent.setPreferredSize(new Dimension(320, 240));
	            	
	                Element gdpdepay = ElementFactory.make("gdpdepay", "gdpdepay");
	            	Element rtph264depay = ElementFactory.make("rtph264depay","rtph264depay");
	            	Element ffdecH264 = ElementFactory.make("ffdec_h264","ffdec_h264");
                    //Element sink = ElementFactory.make("autovideosink", "destination");
	            	Element sink = videoComponent.getElement();
                    sink.set("synk",false);
                    
	                pipe.addMany(videosrc, gdpdepay, rtph264depay, ffdecH264, sink);
	                Element.linkMany(videosrc, gdpdepay, rtph264depay, ffdecH264, sink);

	           //     pipe.addMany(videosrc, , videosink);
	           //     Element.linkMany(videosrc, , videosink);

	                setLayout(new BorderLayout());
	                add(videoComponent, "North");

	                // Start the pipeline processing
	                pipe.setState(State.PLAYING);
	                }
	            });
	     }

}
